**Navegação da V1 — Atlas de Interesses**



Tela 1 — Visão geral

Objetivo: facilitar a retomada do trabalho, sem tentar reproduzir o mapa visual completo antes da V3.

Blocos recomendados:

\- Captura rápida, sempre acessível.

\- Próximas ações marcadas com is\_next\_action: true.

\- Tarefas vencidas ou com prazo próximo.

\- Projetos ativos com status, prazo e progresso.

\- Capturas pendentes para processar.

\- Itens modificados recentemente.

Não é necessário criar uma configuração complexa de widgets na V1. A ordem dos blocos pode ser fixa no primeiro lançamento.



Tela 2 — Atlas / grupos

Lista de grupos

Cada grupo aparece como uma linha ou cartão com nome, cor/ícone opcional, contagem de itens correspondentes e breve descrição. Os grupos são recolhíveis na lista, mas não há canvas ou zoom na V1.

Página de grupo

\- Nome e descrição do grupo.

\- Lista de tags associadas, com ação para adicionar/remover tags.

\- Lista de itens resultante da regra de correspondência por tags.

\- Filtros locais por tipo e status.

\- Ação para criar novo item com tags pré-sugeridas do grupo.

Ao criar um item a partir de um grupo, a interface pode pré-selecionar as tags daquele grupo. A pessoa ainda pode remover tags ou selecionar outras. Não gravar manualmente o ID do grupo dentro do item.

Lista geral de itens

Deve permitir acesso a todos os itens, inclusive aqueles sem tags ou sem correspondência com grupo. Filtros locais por tipo, status e tags são suficientes na V1; a busca global avançada é V2.



Tela 3 — Detalhe de item

Cabeçalho:

\- Título, tipo, status e tags.

\- Grupos em que aparece, calculados automaticamente.

\- Data-alvo e indicador de progresso, se aplicável.

Seções para a V1:

\- Visão geral: resumo, objetivo, datas e status.

\- Tarefas: exibida para projetos.

\- Notas: notas contextuais e notas permanentes ligadas por links.

\- Histórico básico: datas de criação/alteração; histórico completo de versões não é obrigatório.

Detalhe de projeto

A página de projeto deve deixar acessíveis sem navegação profunda:

\- objetivo e status;

\- progresso total e previsão de conclusão;

\- próximas ações;

\- lista de tarefas com criação rápida, checkbox/status e prazo;

\- notas contextuais;

\- notas permanentes ligadas às notas do projeto;

\- tags do projeto e grupos derivados dessas tags.



Tela 4 — Caixa de entrada

Captura

Um campo de texto rápido aceita uma frase, link ou ideia. O cadastro inicial deve exigir o mínimo possível: conteúdo e, opcionalmente, título/tipo. O horário de captura é automático.

Processamento

Cada captura oferece ações para:

\- converter em item (projeto, curso, interesse, ideia, trilha ou meta);

\- converter em tarefa (opcionalmente vinculada a um projeto);

\- converter em nota de trabalho/leitura/permanente;

\- arquivar sem conversão.

Ao converter, manter o texto original e o ID da captura na entidade criada. Não excluir a captura automaticamente.



Tela 5 — Tarefas

Visões locais:

\- Todas as tarefas abertas.

\- Próximas ações.

\- Vencidas e com prazo próximo.

\- Agrupadas por projeto.

\- Concluídas/arquivadas, sob demanda.

Filtros básicos: status, projeto, prioridade e prazo. Tarefas sem project\_id aparecem em “Sem projeto”. A ação de concluir atualiza completed\_at; reabrir limpa esse campo.



Tela 6 — Notas

Navegação por tipo

\- Contextuais/de trabalho: organizadas na interface dentro do item associado.

\- Leitura: com campos opcionais da fonte; podem pertencer a um item ou ser independentes.

\- Permanentes: base global de ideias elaboradas e reutilizáveis.

Editor

\- Título e corpo Markdown.

\- Salvamento automático ou botão de salvar explícito, com indicação de estado salvo.

\- Inserção de link para outra nota usando um seletor de notas.

\- Painel de links de saída e backlinks.

\- Metadados editáveis em campos de formulário, sem exigir edição manual do YAML para o uso cotidiano.

O seletor de notas pode localizar notas por título/ID para construir links; isso é uma função específica de ligação entre notas, não substitui a busca global avançada da V2.

Promover uma ideia a nota permanente

Na nota de trabalho/leitura, oferecer “Criar nota permanente a partir desta”. A aplicação cria um novo arquivo global, pré-preenche título/conteúdo inicial e adiciona o link para a origem. A nota contextual original é mantida.



Tela 7 — Organização

Gerenciador de grupos

Criar, renomear, ordenar, arquivar e editar descrição/estilo do grupo. O editor apresenta uma lista de tags existentes com seleção múltipla e permite criar uma tag nova sem sair do fluxo.

Gerenciador de tags

Criar, renomear, editar descrição/cor, arquivar e visualizar onde a tag é usada. Se uma tag for renomeada, atualiza-se o arquivo/metadado, não as referências por ID.

A remoção de uma tag de um grupo pode fazer itens deixarem de aparecer nesse grupo; mostrar uma prévia/aviso antes de confirmar. Excluir uma tag usada em itens ou grupos deve ser substituído por arquivamento ou por uma ação explícita de substituição de tag.

Fluxos principais de navegação

Criar um projeto a partir de uma ideia

Visão geral → Captura rápida → Caixa de entrada → Processar → Criar projeto → Selecionar tags → Definir status/prazo → Abrir projeto → Criar tarefas

Conectar uma nota de projeto a uma nota permanente

Projeto → Notas contextuais → Abrir nota → Inserir link para nota permanente → Salvar → Ver link/backlink

Fazer um item aparecer em dois grupos

Organização → Grupos → Associar a mesma tag aos dois grupos → Atribuir essa tag ao item → Confirmar que aparece em ambos

A operação não cria cópias: os dois grupos consultam a mesma entidade.

