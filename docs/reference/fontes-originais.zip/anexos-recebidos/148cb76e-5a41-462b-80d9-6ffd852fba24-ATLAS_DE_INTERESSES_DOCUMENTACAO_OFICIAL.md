# ATLAS DE INTERESSES
## Documentação oficial do produto e plano de construção

**Versão do documento:** 1.0  
**Data:** 17 de outubro de 2026  
**Status:** baseline oficial do produto; roadmap V0–V5 definido em nível funcional  
**Responsável pelo produto:** proprietária do projeto  
**Propósito deste documento:** orientar decisões, implementação, testes e colaboração com múltiplas IAs.

> **Regra de precedência:** este documento registra a intenção oficial do produto. Uma IA, ferramenta de desenvolvimento ou colaborador não deve substituir decisões aqui marcadas como **DECIDIDAS** sem explicar a consequência e solicitar aprovação. Recomendações técnicas marcadas como **A VALIDAR NA V0** ainda não são decisões finais.

---

## 0. Como usar esta documentação

Este arquivo deve ser anexado ou disponibilizado no repositório antes de pedir a qualquer IA que trabalhe no Atlas de Interesses. Ele é a fonte principal do contexto de produto, mas não substitui o código, os testes nem os registros de decisão técnica.

### Status das decisões

- **DECIDIDO:** princípio ou comportamento já estabelecido no brainstorming.
- **RECOMENDADO:** caminho sugerido para manter o projeto viável, coerente e testável.
- **A VALIDAR NA V0:** hipótese que deve ser comprovada com protótipo ou pesquisa técnica antes da implementação definitiva.
- **FUTURO:** recurso previsto para uma versão posterior; não antecipar sem autorização.

### Instruções gerais para qualquer IA que receba este documento

1. Leia a documentação integral antes de propor ou escrever código.
2. Preserve os princípios de identidade única, relações derivadas, armazenamento legível e evolução incremental.
3. Diferencie fatos definidos, hipóteses, decisões pendentes e sugestões próprias.
4. Trabalhe somente na versão e na etapa autorizadas. Não implemente V2, V3, V4 ou V5 durante a construção da V1.
5. Antes de uma alteração que afete várias partes do sistema, apresente um plano curto, os arquivos que pretende alterar, riscos e testes.
6. Não substitua o armazenamento principal em Markdown por uma base de dados proprietária ou exclusivamente remota sem aprovação expressa.
7. Não crie botões ou telas de demonstração que aparentem funcionar sem persistência real.
8. Ao concluir uma tarefa, informe: o que mudou, quais testes executou, resultados, limitações conhecidas e próxima decisão necessária.
9. Não invente que algo foi testado ou validado. Informe claramente qualquer teste que não tenha sido executado.
10. Trate a documentação, o modelo de dados, o código e os testes como artefatos que precisam permanecer alinhados.

---

# 1. Visão do produto

## 1.1 Definição

O **Atlas de Interesses** é um sistema pessoal de organização de interesses, projetos, tarefas e conhecimento. Ele combina um atlas navegável de assuntos com uma central de execução e uma base de conhecimento interconectada.

Não é apenas uma lista de tarefas, um aplicativo de notas ou um mapa mental. A proposta é conectar esses usos por meio de um mesmo modelo de dados: interesses podem levar a cursos e ideias; ideias podem amadurecer em projetos; projetos geram tarefas e notas; notas contextualizadas podem produzir conhecimento permanente; e esse conhecimento pode ser reutilizado em outros projetos.

## 1.2 Declaração de missão

Ajudar a transformar curiosidade em conhecimento organizado e conhecimento em trabalho concreto, preservando as conexões entre os assuntos sem exigir que a pessoa preveja antecipadamente onde cada informação será útil.

## 1.3 Resultado esperado para a pessoa usuária

A pessoa deve conseguir:

- explorar áreas temáticas e seus assuntos relacionados;
- registrar uma ideia ou link rapidamente, sem precisar classificá-lo na hora;
- organizar interesses, cursos, ideias, trilhas, metas e projetos;
- executar projetos por meio de tarefas, prazos e próximas ações;
- registrar decisões, descobertas e notas de leitura;
- promover ideias úteis para uma base global de conhecimento permanente;
- perceber conexões entre notas, itens e projetos;
- recuperar seus próprios dados fora da interface, sem ficar presa ao aplicativo;
- fazer backup e, em versões futuras, sincronizar os dados entre dispositivos.

## 1.4 O que o produto não é

- Não é somente um gerenciador de tarefas.
- Não é uma pasta de links sem estrutura.
- Não é uma coleção de notas isoladas.
- Não deve depender de um canvas visual para que os dados sejam acessíveis.
- Não deve criar cópias de um mesmo item para fazê-lo aparecer em mais de um grupo.
- Não deve exigir categorização completa no momento da captura.
- Não deve introduzir IA dentro do produto como funcionalidade central sem uma decisão de escopo separada. As IAs descritas neste documento são, inicialmente, ferramentas para pesquisar, projetar e construir o produto.

## 1.5 Cenário de exemplo

A pessoa se interessa por UX Design. Salva um artigo na Caixa de entrada, depois o transforma em nota de leitura e cria uma tag `UX Design`. Essa tag está associada aos grupos `Design` e `Tecnologia`, então a nota ou o item correspondente pode aparecer nos dois contextos. A pessoa começa um projeto de redesign de aplicativo, cria tarefas e notas de trabalho e relaciona uma nota permanente sobre arquitetura da informação. Meses depois, outro projeto pode reutilizar essa nota permanente sem duplicá-la.

Esse cenário é ilustrativo; nomes como `Design`, `Tecnologia` e `UX Design` são exemplos, não uma lista fechada de grupos ou tags.

---

# 2. Princípios inegociáveis de produto e arquitetura

1. **Markdown é a fonte de verdade. — DECIDIDO**  
   Registros e notas importantes devem existir em arquivos legíveis fora da interface. A aplicação pode manter índices ou caches derivados, mas eles precisam poder ser reconstruídos a partir dos arquivos canônicos.

2. **Identidade independente do título. — DECIDIDO**  
   Cada entidade recebe um identificador estável e único. Renomear um registro não cria outro registro e não deve quebrar relações.

3. **Grupos são vistas derivadas de tags. — DECIDIDO**  
   Os itens exibidos dentro de um grupo são calculados pelas tags que compartilham com ele. Não manter duas relações concorrentes para representar a mesma associação.

4. **Tags classificam; links conectam. — DECIDIDO**  
   Uma tag indica assunto/categoria. Um link entre notas expressa uma conexão de conhecimento explícita. Os dois recursos são complementares e não devem ser tratados como equivalentes.

5. **Um registro, múltiplas visualizações. — DECIDIDO**  
   O mesmo item pode aparecer em vários grupos, listas, mapas ou grafos sem que sejam criadas cópias.

6. **Os dados vêm antes da visualização. — DECIDIDO**  
   O modelo deve funcionar em listas e detalhes antes de depender do mapa visual ou do grafo geral.

7. **Arquivar antes de apagar. — DECIDIDO**  
   Quando um registro é usado por outras entidades, preferir arquivamento ou substituição explícita a exclusão silenciosa que quebre referências.

8. **Persistência real antes de acabamento visual. — RECOMENDADO**  
   Não considerar uma tela pronta se suas ações não persistirem dados e não sobreviverem a fechar/reabrir o aplicativo.

9. **Local-first na primeira versão. — RECOMENDADO, compatível com Markdown como fonte de verdade**  
   Priorizar controle local dos dados e acesso offline na V1. Sincronização entre dispositivos será tratada na V5.

10. **Implementação incremental e verificável. — RECOMENDADO**  
    Cada versão deve acrescentar um conjunto coerente de capacidades com critérios de aceite e testes próprios.

11. **A IA é colaboradora, não autoridade de produto. — DECIDIDO para o workflow**  
    As IAs podem sugerir soluções, mas decisões de escopo, trade-offs e alterações de princípios continuam sob responsabilidade da proprietária do projeto.

---

# 3. Vocabulário oficial

| Termo | Definição no Atlas |
|---|---|
| **Grupo** | Contexto temático abrangente. Mostra itens a partir das tags que compartilha com eles. |
| **Tag** | Classificador reutilizável atribuído a grupos, itens e, quando necessário, notas. |
| **Item** | Registro-base do Atlas: projeto, curso, interesse, ideia, trilha de aprendizagem ou meta. |
| **Projeto** | Item com resultado definido, estado, prazo opcional, tarefas e progresso. |
| **Tarefa** | Ação executável, vinculada a no máximo um projeto ou mantida como tarefa avulsa. |
| **Próxima ação** | Tarefa marcada para destaque como ação que pode ser iniciada em seguida. |
| **Nota contextual** | Nota de trabalho ou leitura associada a um projeto ou outro item. |
| **Nota permanente** | Conhecimento elaborado com palavras próprias e útil além do contexto original. |
| **Caixa de entrada / captura** | Registro temporário de pensamento, link ou possível ação que será processado depois. |
| **Fonte** | Livro, artigo, vídeo, curso, site ou outro material consultado. Na V1, metadados de fonte são básicos; o catálogo completo é previsto para V2. |
| **Vault** | Diretório de arquivos Markdown e anexos mantido como armazenamento canônico. |
| **Link de saída** | Link existente no corpo de uma nota para outra nota ou registro suportado. |
| **Backlink** | Relação inversa calculada: mostra quais notas apontam para a nota atual. |
| **Mapa visual** | Representação navegável do Atlas por nós e conexões; previsto para V3. |
| **Grafo de conhecimento** | Visualização global de relações explícitas e derivadas entre tipos de entidade; previsto para V4. |

---

# 4. Modelo de dados oficial da V1

Os campos abaixo formam a especificação funcional inicial. Na V0, a implementação deve validar detalhes de serialização, nomes de arquivos, IDs e migrações antes de fixá-los no código.

## 4.1 Regras globais de dados

- Todo registro tem `id` estável e `type` explícito.
- Os timestamps usam ISO 8601; datas-alvo podem usar `YYYY-MM-DD`.
- O conteúdo de texto longo fica em Markdown. Metadados estruturados ficam no frontmatter YAML.
- As relações entre entidades usam IDs, não títulos visíveis como chave primária.
- Renomear uma entidade não altera seu ID.
- Arquivos e links internos precisam permanecer válidos após renomear/mover registros.
- Índices de pesquisa, contagens, percentuais, grupos derivados e backlinks são calculados; não criar cópias manuais que possam divergir da fonte.
- Registros arquivados continuam preservados. A interface pode ocultá-los por padrão, mas deve permitir recuperá-los.
- A versão do esquema deve ser explicitada, por exemplo `schema_version: 1`, para permitir migrações futuras.

## 4.2 Entidade `Group` — grupo temático

| Campo | Tipo | Regra |
|---|---|---|
| `id` | string | Obrigatório, único e estável. |
| `type` | string | Sempre `group`. |
| `name` | string | Obrigatório; avisar sobre nomes duplicados. |
| `description` | string | Opcional. |
| `tag_ids` | lista de IDs | Tags associadas ao grupo; pode estar vazia. |
| `sort_order` | inteiro | Define a ordenação de grupos. |
| `color` | string | Opcional; valor de apresentação. |
| `icon` | string | Opcional; identificador de ícone suportado. |
| `created_at` | timestamp | Obrigatório. |
| `updated_at` | timestamp | Atualizar ao editar. |
| `archived_at` | timestamp ou `null` | `null` enquanto ativo. |

**Não armazenar `item_ids` no grupo.** Os itens exibidos são calculados a partir das tags.

## 4.3 Entidade `Tag` — etiqueta

| Campo | Tipo | Regra |
|---|---|---|
| `id` | string | Obrigatório, único e estável. |
| `type` | string | Sempre `tag`. |
| `name` | string | Obrigatório; evitar duplicatas por diferenças de caixa. |
| `slug` | string | Forma normalizada usada em caminhos ou URLs internas quando necessário. |
| `description` | string | Opcional; explica o significado ou limite de uso. |
| `aliases` | lista de strings | Opcional; sinônimos para busca futura, não substituem tags. |
| `color` | string | Opcional. |
| `created_at` / `updated_at` | timestamp | Obrigatórios. |
| `archived_at` | timestamp ou `null` | Arquivamento sem quebrar referências anteriores. |

Uma tag pode ser associada a vários grupos e itens. A associação da tag a grupos é armazenada no `tag_ids` de cada grupo; não manter uma lista espelhada de grupos dentro da tag.

## 4.4 Entidade `Item` — registro-base do Atlas

Tipos suportados na V1: `project`, `course`, `interest`, `idea`, `learning_path` e `goal`.

| Campo | Tipo | Regra |
|---|---|---|
| `id` | string | Obrigatório, único e estável. |
| `type` | enum | Um dos seis tipos definidos acima. |
| `title` | string | Obrigatório. |
| `summary` | string | Descrição curta opcional. |
| `tag_ids` | lista de IDs | Zero ou mais tags existentes. |
| `status` | enum | `backlog`, `planned`, `active`, `paused`, `completed` ou `archived`. |
| `priority` | enum | `low`, `medium` ou `high`; opcional. |
| `start_date` | data ou `null` | Opcional. |
| `target_date` | data ou `null` | Data-alvo opcional. |
| `url` | URL ou `null` | Link externo opcional. |
| `provider` | string ou `null` | Plataforma/instituição, sobretudo para cursos. |
| `progress_mode` | enum | `tasks`, `manual` ou `none`. |
| `manual_progress` | inteiro 0–100 ou `null` | Só usado quando `progress_mode` é `manual`. |
| `objective` | string ou `null` | Principalmente para projetos e metas. |
| `success_criteria` | lista de strings | Critérios para considerar um projeto concluído. |
| `origin_capture_id` | ID ou `null` | Captura de origem, se houver. |
| `created_at` / `updated_at` | timestamp | Obrigatórios. |

Regras por tipo:

- `project`: normalmente usa `progress_mode: tasks`; pode usar `manual` quando contagem de tarefas não representar o progresso real.
- `course`: normalmente usa `progress_mode: manual` na V1. Módulos e currículo detalhado ficam para versão futura.
- `interest` e `idea`: normalmente usam `progress_mode: none`.
- `learning_path` e `goal`: podem usar progresso manual na V1.
- **Não armazenar `group_ids` no item.** A presença em grupos é derivada da interseção de tags.

## 4.5 Entidade `Task` — tarefa ou próxima ação

| Campo | Tipo | Regra |
|---|---|---|
| `id` | string | Obrigatório, único e estável. |
| `type` | string | Sempre `task`. |
| `title` | string | Obrigatório; deve descrever uma ação executável. |
| `description` | string | Opcional; detalhes ou definição de concluído. |
| `project_id` | ID de projeto ou `null` | Se preenchido, deve referenciar um item do tipo `project`. |
| `status` | enum | `todo`, `in_progress`, `done` ou `canceled`. |
| `priority` | enum | `low`, `medium` ou `high`; opcional. |
| `due_date` | data ou `null` | Prazo opcional. |
| `is_next_action` | booleano | Controla destaque na Visão geral. |
| `sort_order` | inteiro | Ordenação em listas/projetos. |
| `origin_capture_id` | ID ou `null` | Captura de origem, se houver. |
| `created_at` / `updated_at` | timestamp | Obrigatórios. |
| `completed_at` | timestamp ou `null` | Preencher ao concluir; limpar se reabrir. |

Na V1, cada tarefa pertence a no máximo um projeto. Subtarefas e dependências entre tarefas ficam fora do escopo inicial.

## 4.6 Entidade `Note` — nota de conhecimento

Toda nota é um arquivo Markdown com metadados estruturados e corpo livre.

| Campo | Tipo | Regra |
|---|---|---|
| `id` | string | Obrigatório, único e estável. |
| `type` | string | Sempre `note`. |
| `note_type` | enum | `work`, `reading` ou `permanent`. |
| `title` | string | Obrigatório. |
| `context_item_id` | ID ou `null` | Item ao qual a nota está associada. |
| `tag_ids` | lista de IDs | Tags opcionais. |
| `source_title` | string ou `null` | Título da fonte para notas de leitura. |
| `source_url` | URL ou `null` | Link para fonte original, quando houver. |
| `source_author` | string ou `null` | Autor da fonte, quando conhecido. |
| `source_year` | inteiro ou `null` | Ano da fonte, quando conhecido. |
| `origin_capture_id` | ID ou `null` | Captura que originou a nota, se houver. |
| `created_at` / `updated_at` | timestamp | Obrigatórios. |

Regras por tipo:

- `work`: rascunhos, decisões, dúvidas e descobertas de um projeto/item. Deve possuir `context_item_id`.
- `reading`: anotações sobre livros, artigos, vídeos, cursos ou outras fontes. Pode ser contextual ou independente.
- `permanent`: nota global, escrita com palavras próprias e reutilizável. Deve usar `context_item_id: null`.

### Links, backlinks e promoção de ideias

- Os links entre notas são links Markdown reais no corpo das notas.
- A aplicação indexa links de saída e calcula backlinks. Não manter uma lista manual duplicada de links no frontmatter.
- Uma nota contextual que amadurece pode gerar uma nova nota permanente. A original deve ser preservada e ligada à nova nota; não mover ou apagar automaticamente o registro original.
- A página de um projeto apresenta suas notas contextuais e as notas permanentes conectadas por links de saída ou backlinks.

## 4.7 Entidade `InboxCapture` — captura rápida

| Campo | Tipo | Regra |
|---|---|---|
| `id` | string | Obrigatório, único e estável. |
| `type` | string | Sempre `inbox_capture`. |
| `title` | string | Opcional; pode ser preenchido ao processar. |
| `capture_kind` | enum | `thought`, `link`, `task`, `project`, `course`, `note` ou `undecided`. |
| `status` | enum | `pending`, `processed` ou `archived`. |
| `captured_at` | timestamp | Automático no momento da captura. |
| `processed_at` | timestamp ou `null` | Preencher ao processar. |
| `converted_to_type` | string ou `null` | Tipo do registro criado. |
| `converted_to_id` | ID ou `null` | ID do registro criado. |

O conteúdo original permanece no corpo Markdown. Ao converter uma captura, o novo registro recebe `origin_capture_id`; a captura original continua armazenada e passa a `processed`.

## 4.8 Relações entre entidades

| Relação | Cardinalidade | Implementação |
|---|---|---|
| Grupo ↔ Tags | Muitos para muitos | Lista `tag_ids` em cada arquivo de grupo. |
| Item ↔ Tags | Muitos para muitos | Lista `tag_ids` em cada arquivo de item. |
| Grupo ↔ Item | Muitos para muitos, derivada | Um item aparece se compartilhar pelo menos uma tag com o grupo. Não armazenar a relação separadamente. |
| Projeto → Tarefas | Um para muitos | `project_id` em cada tarefa; opcional para tarefas avulsas. |
| Item → Notas contextuais | Um para muitos | `context_item_id` nas notas contextuais. |
| Nota ↔ Nota | Muitos para muitos | Links Markdown no corpo; backlinks calculados. |
| Captura → Registro convertido | Zero ou um | `converted_to_type`/`converted_to_id` na captura e `origin_capture_id` no registro gerado. |

### Regra de correspondência de grupos

A V1 usa **qualquer tag em comum (OR)**. Se uma tag do item estiver associada a dois grupos, o item aparecerá em ambos. Item sem tags ou sem correspondência continua acessível na lista geral/área **Sem grupo**. Grupo sem tags pode existir e aparecer vazio.

### Regra de cálculo do progresso de projeto

Quando `progress_mode: tasks`:

`progresso = tarefas concluídas / (tarefas todo + in_progress + done) × 100`

- Tarefas `canceled` não entram no numerador nem no denominador.
- Se não houver tarefas elegíveis, mostrar `Sem tarefas` ou `Progresso não calculado`, não 0% enganoso.
- O modo `manual` usa `manual_progress` de 0 a 100.
- O modo `none` não mostra percentual.
- Concluir todas as tarefas não muda silenciosamente o status do projeto. A interface pode sugerir a conclusão, mas deve pedir confirmação.

---

# 5. Organização de arquivos sugerida

A estrutura é uma proposta inicial e pode mudar durante a V0, desde que os princípios e os IDs permaneçam estáveis.

```text
atlas-interesses/
├── docs/
│   ├── ATLAS_DE_INTERESSES_DOCUMENTACAO_OFICIAL.md
│   ├── AI_CONTEXT.md
│   ├── DATA_MODEL.md
│   ├── ROADMAP.md
│   ├── TEST_PLAN.md
│   ├── ARCHITECTURE_DECISIONS.md
│   └── CHANGELOG.md
├── app/                         # código da aplicação (estrutura técnica a definir)
├── tests/                       # testes automatizados
├── fixtures/                    # dados fictícios para testes, sem dados pessoais
├── vault-example/               # exemplo de vault com registros fictícios
├── scripts/                     # migrações, validações e utilitários
├── AGENTS.md                    # regras permanentes para agentes de código
└── README.md                    # instalação, execução, backup e desenvolvimento
```

Estrutura conceitual do vault:

```text
vault/
├── settings.yml                 # schema_version e preferências do vault
├── groups/                      # um arquivo por grupo
├── tags/                        # um arquivo por tag
├── items/
│   ├── projects/
│   ├── courses/
│   ├── interests/
│   ├── ideas/
│   ├── learning-paths/
│   └── goals/
├── tasks/                       # um arquivo por tarefa
├── inbox/                       # capturas pendentes, processadas ou arquivadas
├── notes/
│   ├── contextual/<item-id>/    # notas ligadas a itens
│   ├── reading/                 # notas de leitura independentes
│   └── permanent/               # base global de notas permanentes
└── assets/                      # anexos locais, quando necessários
```

Regras de armazenamento:

- Um arquivo por entidade, se esse formato for confirmado no protótipo da V0.
- Frontmatter YAML seguido de corpo Markdown.
- IDs únicos; os nomes de arquivos podem incluir IDs ou slugs, mas o título não é a chave primária.
- A aplicação deve resolver relações por ID e atualizar links internos quando renomear ou mover notas.
- `settings.yml` inclui `schema_version`; mudanças incompatíveis precisam de migração explícita.
- Não colocar dados pessoais reais do vault no repositório GitHub. Versionar o código, a documentação e fixtures fictícias. A estratégia de backup do vault deve ser separada e explícita.

---

# 6. Arquitetura de navegação e telas

## 6.1 Regra visual importante

**No mapa de navegação conceitual, a caixa “ATLAS DE INTERESSES” fica centralizada. Não deve ser desenhada como uma barra lateral fixa à esquerda.** As áreas de navegação se distribuem ao redor do hub.

Essa regra se refere ao mapa/hub de navegação conceitual. Ela não obriga que toda tela da aplicação tenha o hub visualizado o tempo inteiro e não proíbe, por si só, uma barra lateral operacional em telas internas, caso a prototipagem de UX demonstre que seja útil.

## 6.2 Áreas de navegação

- **Visão geral:** área operacional para retomar o trabalho.
- **Atlas / Grupos e itens:** exploração temática e acesso aos registros.
- **Projetos:** projetos ativos, pausados, planejados, concluídos e arquivados.
- **Tarefas:** ações globais, próximas ações, prazos e tarefas sem projeto.
- **Caixa de entrada:** capturas a processar.
- **Notas:** notas contextuais, de leitura e permanentes.
- **Organização:** gerenciamento de grupos e tags.
- **Configurações:** localização do vault, preferências, backup, informações de esquema e, no futuro, sincronização.

## 6.3 Tela: Visão geral

Objetivo: ajudar a retomar o trabalho sem virar um painel configurável complexo na V1.

Blocos iniciais:

- captura rápida, sempre acessível;
- próximas ações (`is_next_action: true`);
- tarefas vencidas ou com prazo próximo;
- projetos ativos com status, prazo e progresso;
- capturas pendentes;
- itens alterados recentemente.

Na V1, a ordem pode ser fixa. Personalização avançada de widgets fica fora do escopo inicial.

## 6.4 Tela: Atlas / grupos

### Lista de grupos

Cada grupo exibe nome, descrição curta, cor/ícone opcional e contagem de itens compatíveis. Pode ser apresentado como lista ou cartões. A V1 não exige canvas com zoom.

### Página do grupo

- nome e descrição;
- tags associadas e ação de adicionar/remover;
- lista de itens resultante da regra de tags;
- filtros locais por tipo e status;
- ação para criar item com tags do grupo pré-selecionadas, que ainda podem ser alteradas.

### Lista geral de itens

Deve incluir todos os itens, inclusive os que ainda não têm tags ou não correspondem a nenhum grupo. A V1 usa filtros locais por tipo, status e tags. A busca global avançada está prevista para V2.

## 6.5 Tela: detalhe de item/projeto

Cabeçalho:

- título, tipo, status e tags;
- grupos derivados das tags;
- prazo-alvo e indicador de progresso, quando aplicáveis.

Seções:

- **Visão geral:** resumo, objetivo, datas e status;
- **Tarefas:** em itens do tipo projeto;
- **Notas:** notas contextuais e notas permanentes ligadas;
- **Histórico básico:** datas de criação e alteração. Histórico completo de versões não é exigido na V1.

O detalhe de projeto deve manter facilmente acessíveis objetivo, status, progresso, previsão de conclusão, próximas ações, tarefas, notas contextuais, notas permanentes conectadas, tags e grupos derivados.

## 6.6 Tela: Caixa de entrada

A captura rápida aceita frase, link ou ideia com o menor número possível de campos. O conteúdo e o horário de captura são suficientes para iniciar; título e tipo podem ser opcionais.

Cada captura deve poder ser processada como:

- item: projeto, curso, interesse, ideia, trilha ou meta;
- tarefa avulsa ou vinculada a projeto;
- nota de trabalho, leitura ou permanente;
- arquivamento sem conversão.

A conversão não apaga a captura original.

## 6.7 Tela: Tarefas

Visões iniciais:

- tarefas abertas;
- próximas ações;
- tarefas vencidas/com prazo próximo;
- tarefas agrupadas por projeto;
- tarefas concluídas/arquivadas sob demanda.

Filtros iniciais: status, projeto, prioridade e prazo. Tarefas sem `project_id` aparecem em `Sem projeto`. Concluir atualiza `completed_at`; reabrir limpa o campo.

## 6.8 Tela: Notas

- Notas contextuais/de trabalho são encontradas dentro do item associado.
- Notas de leitura podem ter metadados da fonte e ser contextuais ou independentes.
- Notas permanentes compõem a base global reutilizável.
- O editor tem título, corpo Markdown, metadados editáveis, salvamento confirmado (automático ou explícito), inserção de link para outra nota, links de saída e backlinks.
- O uso cotidiano não deve exigir que a pessoa edite YAML manualmente.
- O seletor de notas deve localizar por título/ID para gerar links válidos; isso não substitui a busca global completa da V2.
- A ação **Criar nota permanente a partir desta** deve criar nova nota global, pré-preencher conteúdo e linkar a origem, mantendo a nota contextual.

## 6.9 Tela: Organização

O gerenciador de grupos permite criar, renomear, ordenar, arquivar e editar descrição/estilo; também associa tags existentes ou cria uma nova sem sair do fluxo.

O gerenciador de tags permite criar, renomear, editar descrição/cor, arquivar e visualizar onde a tag é usada. Remover tag de um grupo deve mostrar uma prévia/aviso sobre os itens afetados. Tag usada por registros deve ser arquivada ou substituída explicitamente, não apagada silenciosamente.

## 6.10 Fluxos essenciais

**Transformar ideia em projeto:**

`Visão geral → Captura rápida → Caixa de entrada → Processar → Criar projeto → Selecionar tags → Definir status/prazo → Abrir projeto → Criar tarefas`

**Conectar nota contextual a nota permanente:**

`Projeto → Notas contextuais → Abrir nota → Inserir link para nota permanente → Salvar → Conferir backlink`

**Fazer o mesmo item aparecer em dois grupos:**

`Organização → Grupos → Associar a mesma tag aos dois grupos → Atribuir essa tag ao item → Verificar presença nos dois grupos sem duplicação`

---

# 7. Roadmap oficial: V0 + cinco versões

A **V0** é a fase de preparação e prova técnica anterior às cinco versões de produto. A **V5** é o fim do roadmap inicial aprovado neste documento, não uma declaração de que o produto nunca mais evoluirá.

## V0 — Descoberta, validação e fundação

**Objetivo:** retirar ambiguidades críticas, provar a abordagem de armazenamento e montar uma fundação técnica segura antes de desenvolver o produto inteiro.

### Incluído

- consolidar visão, glossário, regras e fluxos;
- separar decisões fechadas das decisões ainda abertas;
- desenhar protótipos de baixa fidelidade das telas principais;
- comparar arquitetura local-first com alternativas web/cloud;
- construir uma prova de conceito pequena para criar, ler, editar e persistir um grupo, uma tag, um item, uma tarefa e uma nota Markdown;
- testar IDs estáveis, correspondência de grupos por tags, links de notas, backup e restauração;
- escolher a stack tecnológica com base em evidência, não apenas na facilidade de gerar uma interface;
- criar repositório privado de código, regras de colaboração com IAs e estrutura mínima de testes;
- registrar decisões técnicas em `ARCHITECTURE_DECISIONS.md`.

### Não incluído

- app completo;
- mapa com zoom;
- grafo geral;
- sincronização;
- catálogo global completo de fontes;
- acabamento visual detalhado antes de validar os fluxos.

### Saídas obrigatórias

1. documentação revisada e aprovada;
2. protótipo navegável de baixa fidelidade;
3. decisão de arquitetura registrada, com alternativas e trade-offs;
4. prova de conceito de leitura/escrita de Markdown e backup/restauração;
5. exemplo fictício de vault;
6. estrutura de repositório com instruções de execução;
7. plano de testes da V1;
8. lista explícita de riscos e decisões pendentes.

### Critérios para encerrar a V0

- A proprietária consegue explicar os fluxos de captura, classificação, projeto e notas sem contradições.
- O sistema consegue salvar e recarregar dados reais de um arquivo/vault; não há apenas estado na memória do navegador.
- Alterar o título não altera o ID do registro.
- Os itens entram nos grupos corretos com a regra OR, sem cópias.
- Um backup pode ser restaurado em um diretório de teste.
- A arquitetura escolhida é compatível com a diretriz de Markdown como fonte de verdade ou há aprovação explícita e documentada de uma mudança nesse princípio.
- O repositório pode ser clonado e executado seguindo o README.

**Gate de aprovação:** não começar a implementar o escopo completo da V1 enquanto a prova de conceito de armazenamento e a decisão arquitetural não tiverem sido verificadas.

## V1 — Núcleo funcional local-first

**Objetivo:** entregar uma aplicação pessoal realmente utilizável, com os dados essenciais e sem depender de mapa visual, grafo ou sincronização.

### Incluído

- cadastro, edição, arquivamento e leitura de grupos e tags;
- cadastro e edição de itens nos tipos da V1;
- regras de relação grupo↔tag↔item;
- lista geral de itens e listas de grupo;
- projetos com objetivo, status, prazo e progresso;
- tarefas avulsas ou ligadas a projeto;
- próximas ações, prioridades e prazos;
- notas Markdown contextuais, de leitura e permanentes;
- links entre notas e backlinks;
- caixa de entrada e processamento de capturas;
- Visão geral com próximos passos, projetos ativos e capturas pendentes;
- backup e restauração manuais documentados;
- configurações essenciais do vault e esquema de dados.

### Fora do escopo

- catálogo profundo de livros/cursos/artigos/vídeos;
- busca global avançada e filtros salvos complexos;
- canvas/mapa com zoom;
- grafo global interativo;
- sincronização Android/multidispositivo;
- IA integrada ao produto.

### Critérios de aceite

- Todos os registros são persistidos e sobrevivem ao fechamento/reabertura.
- Um item com tag comum aparece em todos os grupos correspondentes; itens sem grupo continuam acessíveis.
- As telas não criam entidades duplicadas para exibição em mais de um contexto.
- O progresso exclui tarefas canceladas e lida corretamente com projetos sem tarefas.
- Capturas processadas preservam conteúdo original e referência para o registro convertido.
- Links Markdown e backlinks são consistentes após salvar e recarregar.
- Backup e restauração funcionam com um vault de teste.
- Os fluxos principais têm testes automatizados e um roteiro de aceitação manual.

## V2 — Pesquisa, recuperação e catálogo de fontes

**Objetivo:** tornar o conhecimento registrado mais fácil de encontrar, compreender e reutilizar.

### Incluído

- busca global em títulos e conteúdos de itens, tarefas e notas;
- filtros combináveis por tipo, grupo derivado, tag, status e data;
- catálogo de fontes mais estruturado para livros, artigos, vídeos, cursos e sites;
- relação explícita entre notas de leitura e fontes;
- metadados ampliados de fonte, conforme a necessidade validada;
- atalhos de navegação e seletor de notas melhorado;
- resultados de busca que conduzam ao registro original, não a uma cópia;
- reconstrução de índice de pesquisa a partir do vault.

### Regras de escopo

- A busca e o catálogo não substituem Markdown como fonte canônica.
- Definir uma entidade `Source` dedicada somente se os casos de uso mostrarem que os campos atuais das notas são insuficientes. Registrar essa decisão antes da migração.
- Importações automatizadas de conteúdo e coleta massiva de fontes não entram automaticamente nesta versão.

### Critérios de aceite

- Uma busca encontra conteúdo presente no corpo de notas, não apenas títulos.
- Filtros podem ser combinados de forma previsível.
- O índice pode ser reconstruído se for apagado, sem perda de registros.
- Fontes repetidas podem ser vinculadas por ID/referência, sem replicar metadados em notas diferentes desnecessariamente.
- Pesquisa não quebra links, IDs ou desempenho básico da V1.

## V3 — Mapa visual interativo do Atlas

**Objetivo:** permitir exploração visual dos interesses e dos itens que os compõem.

### Incluído

- canvas ou mapa visual com zoom e pan;
- navegação entre grupos, tags e itens;
- agrupamento visual coerente com a estrutura temática;
- seleção de nó para abrir detalhes;
- navegação de volta ao mapa sem perder contexto;
- filtros por tipo/status e controles para reduzir ruído visual;
- indicação visual de itens em múltiplos grupos sem duplicar sua identidade;
- acessibilidade e alternativa em lista para operações essenciais.

### Regras de escopo

- O mapa é uma visualização de registros existentes, não uma nova base de dados.
- A disposição espacial dos nós não deve ser a única maneira de encontrar ou editar conteúdo.
- A V3 é para o mapa do Atlas; um grafo global de todos os tipos de relações fica para V4.

### Critérios de aceite

- Zoom, pan, abrir e voltar funcionam em conjuntos de dados representativos.
- Editar tags ou arquivar itens atualiza as visualizações derivadas.
- Um item pertencente a vários grupos mantém um único ID e uma identidade rastreável.
- Há forma de navegar e operar sem depender exclusivamente de movimento/gestos ou cor.
- O mapa não torna o aplicativo impraticável em telas menores ou com muitos nós.

## V4 — Grafo geral de conhecimento

**Objetivo:** tornar exploráveis as relações explícitas e derivadas entre notas, itens, tarefas, fontes, tags e grupos.

### Incluído

- grafo global de conhecimento;
- relações explícitas originadas de links e relações derivadas do modelo;
- backlinks e caminhos entre notas e projetos;
- filtros por tipo de nó, tipo de relação, tag, grupo e status;
- abertura de detalhes a partir de um nó;
- distinção visual entre relação explícita e relação inferida/derivada;
- limites de visualização e controles para lidar com grafos grandes.

### Regras de escopo

- Não persistir como relações explícitas relações que já são derivadas de tags; isso criaria duas fontes de verdade.
- O grafo é uma camada de exploração, não uma substituição às páginas de detalhes e às listas.
- Não introduzir inferências baseadas em IA sem nova decisão de produto, política de transparência e critérios de verificação.

### Critérios de aceite

- Cada conexão exibida pode ser explicada pela fonte correspondente: link real, ID relacional ou regra derivada documentada.
- Filtros reduzem o grafo de forma previsível.
- Abrir um nó sempre leva ao registro correto.
- Arquivar/renomear registros não cria conexões fantasmas.
- O app continua funcional quando o usuário opta por não abrir o grafo.

## V5 — Sincronização e experiência Android

**Objetivo:** manter o mesmo sistema pessoal acessível em mais de um dispositivo sem sacrificar a integridade dos arquivos e das relações.

### Incluído

- experiência de uso otimizada para Android;
- sincronização entre dispositivos, com funcionamento offline quando viável;
- backup automatizado configurável;
- detecção e resolução de conflitos de edição;
- logs/indicadores de sincronização, erro e última atualização;
- recuperação de conflitos sem sobrescrever silenciosamente conteúdo;
- estratégia de privacidade, autenticação e proteção dos dados em trânsito e armazenados;
- documentação de recuperação e migração de dispositivo.

### Regras de escopo

- A V5 exige decisão arquitetural formal sobre identidade do usuário, transporte, criptografia, servidor/serviço de sincronização, limites de armazenamento e conflito entre versões de arquivos.
- Não assumir que sincronizar pastas é suficiente para resolver conflitos de metadados, links e IDs.
- Não sincronizar o vault com serviços remotos sem consentimento e indicação explícita de estado.

### Critérios de aceite

- Edições em dois dispositivos são sincronizadas ou apresentadas como conflito recuperável.
- Nenhuma edição é descartada silenciosamente.
- A pessoa consegue identificar quando os dados estão sincronizados, pendentes ou com erro.
- A aplicação funciona dentro do comportamento offline definido.
- Testes cobrem conflitos, restauração de backup, perda de conexão e atualização de esquema.
- Existe procedimento documentado para exportar todos os dados em formato legível.

---

# 8. Decisão de arquitetura: recomendação inicial para a V0

## 8.1 Requisito que condiciona a tecnologia

O requisito mais importante para selecionar a tecnologia é: **o Markdown é a fonte de verdade e o sistema deve poder ler e gravar arquivos de um vault**. Portanto, uma ferramenta que gera rapidamente uma interface web não é automaticamente adequada para a aplicação final.

## 8.2 Arquitetura candidata

**RECOMENDADO para ser testado na V0:** aplicativo local-first com interface web e camada nativa de acesso ao sistema de arquivos, usando uma stack multiplataforma. Uma combinação como **Tauri 2 + React + TypeScript** é candidata de prova técnica, não decisão definitiva.

A documentação oficial do Tauri descreve um plugin de sistema de arquivos com permissões e escopos explícitos; a aplicação deve conceder apenas o acesso que realmente precisa e validar com cuidado o comportamento no desktop e, mais tarde, no Android. Referência: [documentação do plugin de arquivos do Tauri](https://v2.tauri.app/plugin/file-system/)

## 8.3 Alternativas a comparar na V0

| Alternativa | Vantagem potencial | Risco/pergunta que precisa ser provada |
|---|---|---|
| App local-first com camada nativa (ex.: Tauri) | Controle de arquivos locais e possível caminho multiplataforma. | Permissões, acesso a vault escolhido, comportamento Android e esforço de empacotamento. |
| Aplicação web/PWA com acesso a arquivos | Protótipo web simples e compartilhável. | Compatibilidade de APIs de arquivos, diferenças entre navegadores e limitações de acesso persistente. |
| Aplicação web com banco remoto como fonte canônica | Compartilhamento/sincronização podem ser mais naturais. | Muda a regra de Markdown como fonte de verdade; exige aprovação explícita e estratégia de exportação/importação. |
| Construtor visual/no-code | Validação rápida de interface e fluxos. | Pode esconder ou limitar a camada de arquivos, migrações, testes e controle de persistência. Deve ser avaliado só com os requisitos em mãos. |

## 8.4 Prova técnica mínima

Antes de fechar a stack, implementar um protótipo isolado que demonstre:

1. criar e salvar um grupo em arquivo;
2. criar tag e associá-la ao grupo;
3. criar item e associar tag;
4. listar item no grupo por correspondência de tags;
5. renomear item mantendo ID e relações;
6. editar/salvar nota Markdown com link para outra nota;
7. fechar e reabrir o app e recuperar os dados;
8. exportar/duplicar um vault e restaurá-lo em outro diretório;
9. apresentar erros de permissão ou gravação sem fingir que salvou;
10. provar quais permissões de arquivo a aplicação exige.

---

# 9. Workflow definitivo da proprietária: da V0 à V5

Este é o processo recomendado de trabalho. As IAs auxiliam tarefas específicas; a proprietária aprova as decisões e valida os resultados reais.

## Ciclo de trabalho padrão para qualquer funcionalidade

1. **Definir:** escrever o problema e o resultado observável em uma frase.
2. **Localizar:** identificar a versão, os requisitos oficiais e os arquivos relacionados.
3. **Planejar com IA:** pedir um plano antes do código; exigir arquivos a alterar, dependências, riscos e testes.
4. **Aprovar:** conferir o plano e limitar o escopo.
5. **Implementar:** uma única IA de código por tarefa altera o repositório.
6. **Testar:** executar testes automatizados e verificar o fluxo em uso real.
7. **Revisar independentemente:** outra IA pode revisar o diff e os critérios sem reescrever tudo.
8. **Aceitar ou rejeitar:** comparar o resultado com os critérios de aceite, não só com a aparência.
9. **Registrar:** atualizar documentação, changelog e decisões técnicas quando pertinente.
10. **Salvar um marco:** commitar no Git ou criar uma release somente depois de testes passarem.

### Regra de controle

Nunca pedir a várias IAs para alterar simultaneamente o mesmo conjunto de arquivos. Use uma IA como implementadora principal e, opcionalmente, outra para revisão independente. Não misture mudanças de várias versões no mesmo pedido.

## V0 — passo a passo

### V0.1 — Congelar o contexto de produto

- Guardar este documento e o `AI_CONTEXT.md` no mesmo diretório de projeto.
- Registrar uma lista de decisões **DECIDIDAS**, **A VALIDAR** e **FUTURAS**.
- Pedir a uma IA revisora que procure contradições e omissões, sem alterar as decisões silenciosamente.
- Resolver primeiro contradições que impeçam o modelo de dados ou os fluxos essenciais.

**Ferramentas:** ChatGPT para consolidar; Claude ou Codex como segunda leitura crítica; decisão final da proprietária.

### V0.2 — Testar os fluxos e desenhar wireframes

- Desenhar fluxo de captura → processamento → projeto/tarefa/nota.
- Desenhar lista de grupos, página de grupo, detalhe de item e detalhe de projeto.
- Desenhar editor de notas e ligação entre nota contextual e nota permanente.
- Confirmar a centralização da caixa `ATLAS DE INTERESSES` no mapa conceitual.
- Testar se alguém entende as telas sem instruções longas.

**Ferramentas:** ChatGPT para requisitos e casos de uso; Figma/FigJam ou ferramenta equivalente para wireframes; ferramenta visual geradora apenas se ajudar a comparar opções sem prender a arquitetura.

### V0.3 — Fazer pesquisa baseada em fontes

- Reunir esta especificação, os documentos de navegação e as referências relevantes em um notebook de pesquisa.
- Pesquisar padrões de notas, links, vault, pesquisa, mapa e sincronização, registrando a fonte de cada recomendação.
- Separar práticas comprovadas de preferências pessoais.
- Não adotar uma metodologia completa (ex.: PARA/Zettelkasten) sem traduzir suas partes úteis aos requisitos do Atlas.

**Ferramentas:** Gemini Notebook (antigo NotebookLM) para consultar fontes fornecidas e comparar informações; navegador/páginas oficiais para verificar documentação técnica atual.

### V0.4 — Comparar a arquitetura

- Criar tabela de decisão entre app local-first, web/PWA e backend remoto.
- Avaliar: acesso a arquivos, legibilidade fora do app, execução offline, backup, complexidade, Android futuro, sincronização e manutenção.
- Fazer a prova técnica mínima da seção 8.4.
- Documentar a conclusão e a alternativa rejeitada em `ARCHITECTURE_DECISIONS.md`.

**Ferramentas:** ChatGPT/Codex para comparar trade-offs; Cursor ou Codex para implementar a prova; segunda IA para revisar código e resultados. Não escolher pela demonstração visual.

### V0.5 — Preparar o repositório

- Criar repositório **privado** no GitHub para código e documentação.
- Criar `README.md`, `AGENTS.md`, `docs/`, `tests/` e `fixtures/`.
- Incluir regras permanentes para agentes: ler docs primeiro, escopo limitado, testes, sem segredos, sem dados pessoais reais.
- Configurar dependências e testes mínimos.
- Criar vault de exemplo com dados fictícios.
- Verificar clone limpo e execução conforme instruções.

**Ferramentas:** GitHub para versionamento; Cursor como ambiente principal sugerido; Codex como revisão secundária opcional.

### V0.6 — Encerrar a V0

Conferir os critérios de saída da V0. Não avançar até armazenamento, IDs, regras de tags e backup/restauração estarem comprovados. Registrar dúvidas residuais sem escondê-las.

## V1 — passo a passo de implementação

1. Implementar parser/validação de frontmatter e operações de leitura/gravação de arquivos.
2. Implementar geração e preservação de IDs.
3. Implementar CRUD de tags e grupos.
4. Implementar itens e a regra derivada de inclusão em grupos.
5. Implementar detalhe/lista de projeto, tarefas, prioridades, prazos e progresso.
6. Implementar notas Markdown, links, backlinks e promoção de nota permanente.
7. Implementar Caixa de entrada e conversão de capturas preservando a origem.
8. Implementar Visão geral e filtros locais.
9. Implementar arquivo/recuperação de registros, backup e restauração.
10. Executar testes unitários, integração, regressão e roteiro manual.
11. Fazer correções de dados, acessibilidade e comportamento antes do polimento visual final.
12. Publicar a V1 somente depois de todos os critérios de aceite passarem.

**Papel da proprietária:** testar os fluxos com dados fictícios, comparar a interface com os wireframes e confirmar que nenhum dado desaparece ou duplica.

## V2 — passo a passo

1. Reunir exemplos reais e fictícios de buscas que a V1 não resolve adequadamente.
2. Definir escopo da busca global: conteúdo indexado, filtros e ordenação.
3. Decidir se uma entidade `Source` própria é necessária.
4. Implementar índice derivado que pode ser reconstruído a partir do vault.
5. Implementar catálogo mínimo de fontes e referências a partir das notas.
6. Testar resultados, filtros combinados, conteúdo acentuado/Unicode e reindexação.
7. Comparar o desempenho e a integridade da versão com a V1.
8. Atualizar documentação e liberar apenas quando os critérios de aceite forem atendidos.

## V3 — passo a passo

1. Definir tarefas que o mapa deve resolver, evitando criar um mapa só por aparência.
2. Prototipar posições, agrupamentos, zoom, pan, navegação e retorno ao contexto.
3. Estabelecer limites e estratégia para muitos nós.
4. Implementar visualização sobre dados existentes, sem duplicar o modelo de dados.
5. Conectar nós às páginas de detalhe.
6. Garantir alternativa em lista, teclado/foco e leitura em telas menores.
7. Testar mudanças nas tags e verificar que o mapa atualiza as vistas derivadas.
8. Fazer teste de usabilidade com tarefas concretas de exploração.

## V4 — passo a passo

1. Inventariar todas as relações explícitas e derivadas existentes.
2. Definir a representação de cada tipo de nó e conexão.
3. Distinguir graficamente links reais de relações calculadas.
4. Implementar filtros, limites e acesso aos detalhes.
5. Testar nós isolados, ciclos de links, entidades arquivadas e grandes conjuntos de dados.
6. Verificar que nenhuma relação é persistida duas vezes.
7. Documentar como cada conexão exibida é obtida.
8. Liberar quando a visualização for útil sem comprometer as listas e páginas normais.

## V5 — passo a passo

1. Definir dispositivos-alvo, estado offline esperado e requisitos de privacidade.
2. Escolher estratégia de identidade, serviço de sincronização e transporte.
3. Especificar conflito entre duas versões de um arquivo e como manter as versões recuperáveis.
4. Construir sincronização mínima com logs e indicadores explícitos de estado.
5. Testar edição offline, duas edições concorrentes, interrupção de conexão e restauração.
6. Desenvolver interface Android e validar navegação, captura rápida, leitura/escrita e sincronização.
7. Definir backup automático, exportação completa e recuperação de conta/dispositivo.
8. Realizar revisão de segurança, privacidade e permissões.
9. Executar testes de regressão em V1–V4.
10. Liberar gradualmente, mantendo mecanismo de retorno/recuperação documentado.

---

# 10. Quais IAs usar e para quê

O workflow recomendado usa poucas ferramentas com papéis claros. As ferramentas mudam com frequência; confirmar capacidades, preços, limites e disponibilidade antes de assumir compromissos. As fontes oficiais no fim desta seção foram consultadas em 17 de outubro de 2026.

## 10.1 Matriz de responsabilidades

| Ferramenta | Papel principal no Atlas | Use para | Não delegar exclusivamente a ela |
|---|---|---|---|
| **ChatGPT** | Arquitetura de produto e coordenação | Transformar ideias em requisitos; manter coerência; preparar prompts; dividir versões em tarefas; discutir alternativas; revisar fluxos e critérios de aceite. | Decidir silenciosamente stack ou escopo; afirmar que código foi testado sem evidência. |
| **Gemini Notebook (antigo NotebookLM)** | Pesquisa com fontes fornecidas | Consultar livros, artigos, documentos técnicos e notas de pesquisa; identificar ideias apoiadas nas fontes; produzir sínteses com rastreabilidade. | Decidir arquitetura sem protótipo; substituir documentação técnica atual das ferramentas. |
| **Cursor Agent** | Implementador principal recomendado | Explorar repositório, editar vários arquivos, executar terminal, construir funcionalidades, escrever testes e corrigir erros. | Alterar várias versões sem controle; fazer mudanças amplas sem plano/revisão. |
| **Codex** | Revisor de código independente ou alternativa ao Cursor | Revisar diffs, procurar bugs, avaliar qualidade, ajudar a testar/debugar; pode também ser o implementador principal se for a ferramenta escolhida. | Trabalhar como segundo implementador simultâneo nos mesmos arquivos. |
| **Claude / Claude Code** | Segunda leitura crítica ou alternativa de codificação | Criticar a especificação, procurar contradições, revisar a arquitetura e, se escolhido no lugar do Cursor, trabalhar no repositório/terminal. | Criar uma terceira linha de implementação paralela sem integração. |
| **Figma/FigJam ou equivalente** | Wireframes e testes de UX | Construir telas de baixa fidelidade, fluxos e protótipos para testar navegação antes do código. | Ser tratado como prova de que o armazenamento funciona. |
| **Lovable ou Dyad** | Protótipo visual opcional | Explorar uma direção de interface rapidamente e testar layout/fluxos. | Ser a arquitetura final por padrão. Só avançar se a estratégia de Markdown/vault e exportação de código tiver sido validada. |
| **GitHub** | Fonte de verdade do código e histórico | Repositório privado, branches, diffs, issues, tags de versão, documentação e recuperação do código. | Guardar automaticamente o vault pessoal real ou segredos no repositório. |

## 10.2 Combinação padrão recomendada

**Principal:** ChatGPT + Gemini Notebook (antigo NotebookLM) + Cursor + GitHub.  
**Revisão opcional:** Codex ou Claude, uma ferramenta de cada vez como revisor independente.

A escolha do Cursor como implementador primário é uma recomendação operacional, não uma exigência. Sua documentação descreve um agente capaz de pesquisar a base de código, editar múltiplos arquivos, executar comandos, escrever testes e corrigir erros. Codex também oferece recursos de escrita, revisão e depuração, então pode substituir o Cursor como implementador se for mais conveniente. Não é necessário manter os dois como autores de código.

Gemini Notebook (antigo NotebookLM) deve funcionar como espaço de pesquisa fundamentada em fontes fornecidas. Quando a dúvida envolver versão atual de uma biblioteca, permissões, instalação ou API, consultar também a documentação oficial atual.

Lovable/Dyad pode acelerar a exploração de UI, mas o requisito de acesso a arquivos Markdown deve ser demonstrado antes de usar o construtor como implementação principal. Integrações de código e backend não provam, por si só, que a aplicação preserva o vault como fonte canônica.

## 10.3 Fluxo recomendado entre as IAs

1. **ChatGPT:** traduzir objetivo em tarefa, critérios de aceite e plano de implementação.
2. **Gemini Notebook (antigo NotebookLM):** pesquisar apenas se a tarefa depender de referências, padrões ou fontes externas; devolver conclusões com fontes.
3. **Cursor:** planejar a mudança, listar arquivos/testes, aguardar aprovação para tarefas estruturais e implementar em branch.
4. **Cursor/testes locais:** rodar testes automáticos e verificar a funcionalidade.
5. **Codex ou Claude:** revisar diff/arquitetura e procurar falhas sem reescrever o trabalho indiscriminadamente.
6. **ChatGPT:** sintetizar revisão, comparar com a especificação e produzir checklist de aceitação.
7. **Proprietária:** testar e aceitar/rejeitar; atualizar documentação e criar commit/release.

## 10.4 Prompts operacionais

### Prompt A — Planejar antes de implementar

> Leia `ATLAS_DE_INTERESSES_DOCUMENTACAO_OFICIAL.md`, `AI_CONTEXT.md` e os arquivos relevantes do repositório. Estamos trabalhando somente na versão **[informar versão]**, funcionalidade **[nome]**. Não escreva código ainda. Apresente: (1) entendimento do objetivo, (2) requisitos e critérios de aceite, (3) arquivos que precisariam ser criados/alterados, (4) riscos e decisões pendentes, (5) testes necessários, (6) o que explicitamente ficará fora do escopo. Respeite os princípios de Markdown como fonte de verdade, IDs estáveis, relações derivadas e ausência de duplicação. Espere aprovação antes de implementar.

### Prompt B — Implementar uma funcionalidade aprovada

> Implemente somente **[funcionalidade]** da versão **[V0/V1/V2/V3/V4/V5]**, seguindo o plano aprovado e a documentação do Atlas. Primeiro confirme o estado do repositório e os testes existentes. Faça uma alteração incremental, preserve APIs/relações existentes e não introduza dependências ou funcionalidades futuras sem justificar. Execute os testes relevantes. Ao finalizar, informe arquivos alterados, comportamento implementado, testes executados e resultados reais, limitações e qualquer decisão que exija minha aprovação. Não declare sucesso em testes que não executou.

### Prompt C — Revisão independente sem editar

> Faça uma revisão independente do diff em relação à documentação oficial do Atlas e aos critérios de aceite da tarefa. **Não altere arquivos.** Procure: perda de dados, IDs instáveis, relações duplicadas, inconsistências de Markdown, grupos calculados incorretamente, tratamento inadequado de erros, falhas de segurança/permissões, regressões, acessibilidade e testes ausentes. Separe achados por severidade (crítico, alto, médio, baixo), cite arquivo/linha quando possível e proponha a menor correção adequada.

### Prompt D — Investigar bug com evidência

> Reproduza ou investigue o defeito **[descrição]** sem assumir a causa. Primeiro identifique o comportamento esperado na especificação, depois reúna evidências (passos, logs, teste ou estado do arquivo), isole a causa e proponha um teste de regressão. Evite refatorações não relacionadas. Depois de aprovação, faça a menor correção e execute os testes afetados.

### Prompt E — Encerrar uma versão

> Compare o estado atual do produto com todos os critérios de aceite de **[versão]**. Verifique código, testes e comportamento executável; não se baseie apenas na descrição anterior. Produza uma tabela: critério, evidência, status (passou/falhou/não verificado), risco e correção necessária. Não proponha iniciar a versão seguinte até que os critérios obrigatórios estejam aprovados ou explicitamente aceitos como pendências pela proprietária.

---

# 11. Estratégia de qualidade, testes e segurança

## 11.1 Pirâmide de testes

### Testes unitários

- validação de frontmatter e tipos;
- IDs estáveis ao renomear;
- correspondência de grupo por qualquer tag comum;
- comportamento de itens sem tags;
- progresso incluindo tarefas `todo`, `in_progress` e `done`, excluindo `canceled`;
- promoção de nota para permanente sem apagar a original;
- atualização de `completed_at` ao concluir/reabrir tarefa;
- leitura e gravação de Unicode e caracteres acentuados.

### Testes de integração

- criar → salvar → fechar → reabrir → recuperar entidade;
- associar tag a dois grupos e verificar item nos dois;
- converter captura em tarefa/projeto/nota preservando origem;
- criar links de notas e reconstruir backlinks;
- renomear/mover arquivo mantendo relações;
- apagar índice e reconstruí-lo a partir do vault;
- backup e restauração em diretório limpo;
- migração de esquema preservando arquivos e IDs.

### Testes de ponta a ponta/aceitação

1. Capturar uma ideia e processá-la em projeto.
2. Criar tarefas, indicar próxima ação e verificar o progresso.
3. Criar nota contextual, ligá-la a uma nota permanente e encontrar backlink.
4. Atribuir tags a um item e confirmar presença em dois grupos.
5. Arquivar registro e confirmar que relações continuam resolvíveis.
6. Fazer backup, restaurar e comparar contagem/conteúdo dos registros.

## 11.2 Segurança e proteção de dados

- Manter repositório de código privado durante a construção inicial.
- Não enviar vault pessoal a serviços externos sem entender o tratamento de dados e dar consentimento.
- Usar fixtures fictícias para testes e demos.
- Não inserir tokens, chaves, senhas ou dados privados em código, logs ou prompts compartilhados.
- Conceder à aplicação apenas as permissões de arquivo necessárias; não liberar acesso global ao sistema sem justificativa.
- Exibir erro real quando uma gravação falhar; nunca mostrar estado salvo se o dado não foi escrito.
- Ter backup e restauração testados, não apenas descritos.
- Antes da V5, documentar transporte, autenticação, criptografia, política de conflito e retenção de dados.

## 11.3 Acessibilidade e UX

- Controles com rótulos acessíveis; não depender apenas de cor.
- Navegação por teclado/foco quando aplicável.
- Confirmação para operações destrutivas e preview de alterações que removam uma tag usada.
- Estados claros de salvo, salvando, erro e sincronização pendente.
- Captura rápida com baixo atrito.
- Alternativas em listas para mapas/grafos.
- Testar telas menores antes de declarar V3 ou V5 prontas.

---

# 12. Riscos e controles

| Risco | Consequência | Controle preventivo |
|---|---|---|
| Escolher construtor apenas pela aparência | Persistência incompatível; reconstrução da arquitetura. | Prova técnica de arquivos e backup na V0. |
| Trocar Markdown por banco remoto sem decisão | Perda de portabilidade e contradição do produto. | Registrar decisão arquitetural e pedir aprovação. |
| Armazenar `group_ids` além de `tag_ids` | Relações duplicadas e dados inconsistentes. | Grupos derivados; teste de regra OR. |
| IDs baseados no título | Renomeações quebram links e relações. | IDs estáveis; teste de renomeação. |
| Implementar mapa antes do modelo | Muitas exceções na interface e dependência do canvas. | V1 em listas/detalhes; mapa apenas em V3. |
| Agentes de código alterarem os mesmos arquivos | Conflitos, mudanças difíceis de revisar. | Um implementador por tarefa; revisão separada. |
| Funcionalidades simuladas sem persistência | Falsa sensação de produto concluído. | Testes após fechar/reabrir e critérios de aceite. |
| Backup não restaurável | Perda de dados. | Teste de restauração em diretório novo. |
| Sincronização sobrescrever conteúdo | Perda irrecuperável de notas. | V5 com conflitos explícitos e histórico/recuperação. |
| Escopo crescer durante cada versão | Projeto não termina. | Gates por versão e backlog futuro separado. |

---

# 13. O que significa “versão final” neste roadmap

Para este plano, **V5 é a versão final do roadmap inicial**, que contempla:

- núcleo funcional para grupos, tags, itens, tarefas, projetos, notas e capturas;
- armazenamento legível e recuperável em Markdown;
- busca global e recuperação de fontes;
- mapa interativo do Atlas;
- grafo geral do conhecimento;
- sincronização e experiência Android;
- backup, restauração, tratamento de conflitos, testes e documentação.

V5 não significa que nenhuma evolução posterior seja possível. Significa que a visão do produto descrita aqui tem um caminho executável até esse nível, sem tentar construir todas as camadas no primeiro lançamento.

---

# 14. Referências oficiais para o workflow de IA e tecnologia

Páginas consultadas em **17 de outubro de 2026**. Ferramentas e preços mudam; confirmar as páginas oficiais antes de tomar decisões comerciais ou de implementação.

1. **Cursor — Agent mode:** descreve pesquisa na base de código, edição de múltiplos arquivos, execução de terminal, escrita de testes e modos de planejamento/debug.  
   [Documentação oficial do Cursor](https://cursor.com/docs)
2. **OpenAI Codex:** visão oficial do agente de desenvolvimento para escrever, revisar e depurar código em diferentes interfaces.  
   [Documentação oficial do Codex](https://developers.openai.com/learn/codex)
3. **Claude Code — documentação oficial:** configuração e fluxos de trabalho para entender, editar e testar código no contexto do projeto.  
   [Documentação oficial do Claude Code](https://docs.anthropic.com/en/docs/claude-code/getting-started)
4. **Gemini Notebook (antigo NotebookLM) — Google:** assistente de pesquisa fundamentado em fontes fornecidas, com citações para rastrear as respostas aos materiais.  
   [Anúncio oficial da mudança para Gemini Notebook](https://blog.google/innovation-and-ai/products/gemini-notebook/notebooklm-gemini-notebook/)
5. **Tauri — File System plugin:** acesso a arquivos com permissões e escopos que precisam ser explicitamente configurados.  
   [Documentação oficial do plugin de sistema de arquivos do Tauri](https://v2.tauri.app/plugin/file-system/)
6. **Lovable — documentação de integrações e código:** referências para integração com GitHub, backend e edição/visualização de código; avaliar apenas se for usado em prototipagem ou se a arquitetura aprovada for compatível.  
   [Integração do Lovable com GitHub](https://docs.lovable.dev/integrations/github)  
   [Integração do Lovable com Supabase](https://docs.lovable.dev/integrations/supabase)  
   [Code mode do Lovable](https://docs.lovable.dev/features/code-mode)

---

# 15. Checklist permanente de governança

Antes de aprovar qualquer funcionalidade:

- [ ] A funcionalidade pertence à versão em andamento.
- [ ] Os critérios de aceite estão escritos.
- [ ] O modelo de dados não foi alterado silenciosamente.
- [ ] Nenhuma relação derivada foi duplicada como dado manual.
- [ ] Os dados são persistidos e recuperáveis.
- [ ] Os testes pertinentes foram executados e seus resultados são verdadeiros.
- [ ] A interface mostra estados de sucesso e erro corretamente.
- [ ] A documentação foi atualizada quando necessário.
- [ ] A revisão do diff não encontrou problemas críticos/altos em aberto.
- [ ] Há um commit/marco recuperável antes da próxima mudança maior.

**Princípio de encerramento:** não medir o progresso do Atlas pela quantidade de telas produzidas. Medir pela quantidade de fluxos reais que a proprietária consegue executar com dados íntegros, recuperáveis e compreensíveis.
