# Atlas de Interesses — Checklist operacional V0 → V5

**Finalidade:** transformar a documentação oficial em uma sequência de trabalho que possa ser acompanhada e marcada.  
**Regra:** só avance quando o gate da etapa estiver aprovado. A V0 prepara o projeto; V1–V5 são as cinco versões do produto.

## Como usar este checklist

- Marque uma tarefa somente depois de executá-la e verificar o resultado.
- Registre decisões de produto em `docs/DECISOES_DO_PRODUTO.md` e decisões técnicas em `docs/ARCHITECTURE_DECISIONS.md`.
- Mantenha código e documentação no GitHub; não coloque um vault pessoal com dados reais no repositório.
- Para cada funcionalidade, use o ciclo padrão: **definir → planejar com IA → aprovar plano → implementar → testar → revisar com outra IA → aceitar/rejeitar → documentar → criar commit**.
- Use apenas **uma IA implementadora por tarefa**. Outra IA pode revisar sem modificar os mesmos arquivos.

---

# Fase 0 — Preparação e prova técnica

## V0.1 — Congelar o contexto do produto

- [ ] Guardar `ATLAS_DE_INTERESSES_DOCUMENTACAO_OFICIAL.md`, `AI_CONTEXT.md` e este checklist em uma pasta de projeto.
- [ ] Ler a documentação integral e validar se a descrição representa o produto desejado.
- [ ] Separar decisões `DECIDIDAS`, recomendações, itens `A VALIDAR NA V0` e recursos futuros.
- [ ] Pedir ao ChatGPT uma revisão de coerência e a Claude ou Codex uma revisão crítica independente; nenhuma IA deve alterar as decisões silenciosamente.
- [ ] Resolver contradições que impeçam o modelo de dados, os fluxos ou a estratégia de armazenamento.
- [ ] Registrar decisões de produto e dúvidas restantes.

**Gate:** a visão, as regras de grupos/tags, a função das notas e a estrutura geral não têm contradições críticas.

## V0.2 — Desenhar e validar a experiência

- [ ] Mapear o fluxo de captura → processamento → criação de projeto/tarefa/nota.
- [ ] Desenhar a Visão geral.
- [ ] Desenhar a lista de grupos e a página de um grupo.
- [ ] Desenhar a lista geral de itens e o detalhe de item/projeto.
- [ ] Desenhar tarefas e próximas ações.
- [ ] Desenhar notas contextuais, de leitura e permanentes, incluindo link e backlink.
- [ ] Desenhar a gestão de grupos/tags e estados de arquivamento.
- [ ] Garantir que o nó `ATLAS DE INTERESSES` apareça **centralizado no mapa conceitual de navegação**, não como barra fixa à esquerda.
- [ ] Fazer um teste rápido de compreensão com tarefas concretas; registrar pontos confusos.
- [ ] Revisar wireframes e fechar o escopo funcional da V1.

**Ferramentas:** ChatGPT para requisitos e cenários; Figma/FigJam ou equivalente para wireframes; prototipadores visuais só para comparar UX.

**Gate:** todos os fluxos essenciais podem ser explicados sem depender de um mapa visual com zoom.

## V0.3 — Pesquisar com fontes verificáveis

- [ ] Reunir documentação oficial, esboços de navegação, restrições técnicas e perguntas abertas.
- [ ] Usar Gemini Notebook (antigo NotebookLM) para comparar os documentos e recuperar recomendações ligadas às fontes fornecidas.
- [ ] Pesquisar documentação técnica oficial atual para opções de armazenamento local, Markdown, backup, permissões e futura sincronização.
- [ ] Anotar a fonte e a justificativa para cada conclusão técnica importante.
- [ ] Separar evidência técnica de preferência estética/pessoal.
- [ ] Não importar integralmente PARA, Zettelkasten ou outro método; adotar somente o que resolve requisitos observados.

**Gate:** existe uma lista curta de alternativas técnicas e de trade-offs fundamentados, sem escolha baseada apenas em uma demo bonita.

## V0.4 — Escolher a arquitetura por evidência

- [ ] Comparar app local-first nativo/híbrido, web/PWA com acesso a arquivos e web com armazenamento remoto.
- [ ] Avaliar: Markdown canônico, portabilidade, acesso offline, permissões, backup/restauração, Android futuro, sincronização, custo e manutenção.
- [ ] Fazer a prova técnica para criar, ler, editar e salvar um grupo, uma tag, um item, uma tarefa e uma nota Markdown.
- [ ] Verificar geração e preservação de IDs após renomeação.
- [ ] Verificar que uma tag compartilhada faz um item aparecer em dois grupos sem criar cópia.
- [ ] Verificar links Markdown e cálculo de backlinks.
- [ ] Fechar e reabrir o aplicativo para comprovar persistência real.
- [ ] Fazer backup e restaurar o vault em outro diretório de teste.
- [ ] Testar erro de permissão/gravação e confirmar que a interface não afirma que salvou.
- [ ] Escolher stack com base nos resultados e documentar vantagens, limites e alternativa rejeitada.
- [ ] Se a solução não puder manter Markdown como fonte de verdade, parar e decidir explicitamente se o princípio será alterado; não contornar silenciosamente.

**Ferramentas:** ChatGPT/Codex para comparar opções; Cursor ou Codex para a prova técnica; outra IA para revisão independente.

**Gate obrigatório:** nenhuma implementação completa da V1 antes da prova técnica de armazenamento, IDs, tags e restauração.

## V0.5 — Preparar repositório e rotina de trabalho

- [ ] Criar repositório privado no GitHub para código e documentação.
- [ ] Criar `README.md`, `AI_CONTEXT.md`, `AGENTS.md`, `docs/`, `tests/` e `fixtures/`.
- [ ] Incluir as regras de trabalho para agentes: ler docs primeiro, mudanças pequenas, escopo controlado, testes, não incluir segredos e não inventar resultados.
- [ ] Criar vault de exemplo com dados fictícios.
- [ ] Configurar testes mínimos e execução local reproduzível.
- [ ] Confirmar que um clone limpo pode ser configurado seguindo o README.
- [ ] Criar o primeiro marco/commit estável.

**Gate:** outra pessoa (ou uma sessão de IA nova) consegue entender o contexto e executar a prova técnica a partir da documentação.

## V0.6 — Aprovar encerramento da V0

- [ ] Documentação oficial e wireframes aprovados.
- [ ] Decisão de arquitetura registrada em `ARCHITECTURE_DECISIONS.md`.
- [ ] Prova técnica de Markdown, IDs, tags, links, persistência e backup aprovada.
- [ ] Vault de exemplo e testes disponíveis.
- [ ] Lista de riscos e decisões pendentes atualizada.
- [ ] Plano de implementação e critérios de aceite da V1 aprovados.

**Gate final da V0:** todos os itens críticos acima foram verificados. Pendências conhecidas estão registradas, têm responsável e não ameaçam a integridade dos dados.

---

# V1 — Núcleo funcional local-first

## Implementação

- [ ] Implementar parser e validação do frontmatter YAML.
- [ ] Implementar operações de leitura/gravação e geração de IDs estáveis.
- [ ] Implementar criação, edição, ordenação, arquivamento e recuperação de grupos.
- [ ] Implementar criação, edição, arquivamento e substituição de tags.
- [ ] Implementar itens: projeto, curso, interesse, ideia, trilha de aprendizagem e meta.
- [ ] Implementar regra de grupo derivado por **qualquer tag em comum (OR)**.
- [ ] Implementar lista geral, incluindo itens sem tags/sem grupo.
- [ ] Implementar projetos: objetivo, status, prioridade, datas e critérios de sucesso.
- [ ] Implementar tarefas avulsas e tarefas vinculadas a, no máximo, um projeto.
- [ ] Implementar prazos, estados, próximas ações e conclusão/reabertura.
- [ ] Implementar progresso automático por tarefas; ignorar tarefas canceladas e tratar projeto sem tarefas.
- [ ] Implementar notas de trabalho, leitura e permanentes em Markdown.
- [ ] Implementar links entre notas, links de saída e backlinks calculados.
- [ ] Implementar promoção de nota contextual para permanente sem apagar a original.
- [ ] Implementar Caixa de entrada e conversão de capturas preservando a origem.
- [ ] Implementar Visão geral com capturas, próximas ações, prazos e projetos ativos.
- [ ] Implementar backup e restauração manual e explicar o procedimento.
- [ ] Implementar estados de salvo, salvando, erro e permissões conforme arquitetura aprovada.

## Testes e aceite

- [ ] Testar criar/salvar/fechar/reabrir cada tipo de registro.
- [ ] Confirmar item em dois grupos sem duplicação.
- [ ] Confirmar comportamento para item sem tags e grupo sem tags.
- [ ] Confirmar que renomear não altera IDs nem quebra relações.
- [ ] Confirmar cálculo de progresso, inclusive sem tarefas e com tarefas canceladas.
- [ ] Confirmar captura convertida preservando o conteúdo original.
- [ ] Confirmar links e backlinks após recarregar/reconstruir índices.
- [ ] Confirmar backup e restauração em diretório limpo.
- [ ] Executar testes unitários, integração, regressão e roteiro manual de aceitação.
- [ ] Pedir revisão de diff por uma IA que não implementou a tarefa.
- [ ] Corrigir falhas e documentar limitações residuais.
- [ ] Atualizar CHANGELOG e criar marco/release da V1.

**Gate V1:** os fluxos centrais funcionam com dados persistidos, sem duplicação, sem perda de dados conhecida e com backup restaurável.

---

# V2 — Busca e catálogo de fontes

- [ ] Reunir exemplos de buscas reais que a V1 não resolve bem.
- [ ] Definir escopo da busca global em títulos e corpo de notas/itens/tarefas.
- [ ] Definir filtros combináveis, ordenação e apresentação dos resultados.
- [ ] Decidir, com justificativa documentada, se é necessária uma entidade `Source` dedicada.
- [ ] Implementar índice de pesquisa derivado e reconstruível a partir do vault.
- [ ] Implementar catálogo mínimo de livros, artigos, vídeos, cursos e sites, conforme casos de uso.
- [ ] Conectar notas de leitura às fontes sem duplicar metadados desnecessariamente.
- [ ] Testar acentos, Unicode, correspondência em conteúdo, filtros combinados e ordenação.
- [ ] Apagar o índice em ambiente de teste e provar que pode ser reconstruído.
- [ ] Verificar que busca e catálogo não quebram IDs nem links.
- [ ] Fazer revisão independente, corrigir regressões, documentar e marcar V2.

**Gate V2:** pesquisa encontra conteúdo integral relevante e filtros previsíveis; índice pode ser reconstruído sem perda.

---

# V3 — Mapa visual interativo

- [ ] Identificar problemas de exploração que o mapa precisa resolver.
- [ ] Prototipar layout, agrupamentos, zoom, pan, seleção de nós, abertura de detalhes e retorno ao mapa.
- [ ] Definir limite/estratégia para conjuntos grandes de nós.
- [ ] Renderizar grupos, tags e itens a partir dos dados existentes.
- [ ] Garantir que um item em vários grupos continue com uma única identidade.
- [ ] Atualizar mapa quando tags, grupos, status ou itens forem alterados.
- [ ] Implementar filtros úteis e redução de ruído visual.
- [ ] Oferecer alternativa de lista para operações essenciais.
- [ ] Testar teclado/foco, telas pequenas, legibilidade, zoom/pan e conjuntos de dados representativos.
- [ ] Fazer testes de usabilidade com tarefas concretas de exploração.
- [ ] Corrigir, documentar e marcar V3.

**Gate V3:** o mapa ajuda a descobrir e navegar sem ser a única forma de acesso ou edição de dados.

---

# V4 — Grafo geral de conhecimento

- [ ] Inventariar relações explícitas (links de nota) e derivadas (tags/grupos/projeto-tarefa).
- [ ] Definir tipos de nós, arestas, filtros e regras de visibilidade.
- [ ] Diferenciar visualmente relações explícitas de relações derivadas.
- [ ] Implementar grafo sobre registros já existentes — sem segunda fonte de verdade.
- [ ] Implementar filtros por tipo de entidade, tipo de relação, grupo, tag e status.
- [ ] Permitir abrir detalhes de nós e percorrer caminhos entre notas/projetos.
- [ ] Definir controles de performance e limites para grafos grandes.
- [ ] Testar links cíclicos, notas isoladas, arquivos arquivados e nós sem conexões.
- [ ] Confirmar que relações não são persistidas duas vezes.
- [ ] Fazer revisão independente, corrigir regressões, documentar e marcar V4.

**Gate V4:** conexões são rastreáveis, sua origem é clara e o grafo permanece uma visualização da base canônica.

---

# V5 — Sincronização e experiência Android

- [ ] Definir dispositivos-alvo, comportamento offline e expectativas de disponibilidade.
- [ ] Escolher e documentar serviço/protocolo de sincronização, identidade e autenticação.
- [ ] Definir comportamento para conflitos entre duas versões do mesmo arquivo.
- [ ] Garantir que conflitos não sejam resolvidos por sobrescrita silenciosa.
- [ ] Implementar estados explícitos de sincronização, erro e pendência.
- [ ] Implementar recuperação de versões/conflitos e logs úteis sem vazar conteúdo sensível.
- [ ] Implementar ou adaptar a experiência Android para captura, navegação, leitura e edição.
- [ ] Testar edição offline, reconexão, duas edições concorrentes e interrupção da rede.
- [ ] Testar permissões, autenticação, criptografia em trânsito e privacidade conforme a arquitetura.
- [ ] Garantir exportação completa, backup automático quando aplicável e restauração de dispositivo.
- [ ] Executar regressão completa dos fluxos V1–V4.
- [ ] Fazer revisão de segurança e acessibilidade.
- [ ] Fazer liberação gradual e documentar como recuperar dados em caso de falha.
- [ ] Registrar limitações remanescentes e criar release V5.

**Gate V5:** sincronização e experiência Android atendem os requisitos aprovados, conflitos são recuperáveis e backups foram restaurados com sucesso em testes reais.

---

# Ciclo obrigatório por funcionalidade (todas as versões)

- [ ] Escrever problema e resultado esperado em uma frase.
- [ ] Informar versão e critérios de aceite.
- [ ] Pedir a uma IA para planejar antes de implementar.
- [ ] Revisar plano, arquivos envolvidos, riscos e testes.
- [ ] Aprovar escopo e deixar explícito o que fica fora.
- [ ] Implementar com uma única IA/agente de código.
- [ ] Executar testes e reproduzir o fluxo manualmente.
- [ ] Revisar o diff com uma segunda IA em modo de revisão, sem edição concorrente.
- [ ] Registrar `passou`, `falhou` ou `não verificado` com evidência real.
- [ ] Atualizar documentação e changelog.
- [ ] Fazer commit/marco apenas após validar o resultado.

# Uso das ferramentas de IA — referência rápida

| Ferramenta | Usar principalmente para | Etapas mais adequadas |
|---|---|---|
| ChatGPT | Produto, requisitos, decisões, critérios de aceite, planos, prompts, triagem de falhas | V0–V5, especialmente planejamento e governança |
| Gemini Notebook (antigo NotebookLM) | Pesquisa baseada em documentos e fontes fornecidas, com rastreabilidade | V0; pesquisa de UX/tecnologia e preparação de V2 |
| Cursor Agent | Implementação principal, exploração do repositório, edição, execução de testes e correções | Prova de conceito V0 e implementação de V1–V5 |
| Codex ou Claude Code | Revisão independente, depuração complexa ou alternativa a Cursor; não usar dois agentes editando os mesmos arquivos | V0 e gates de cada versão |
| Figma/FigJam | Wireframes, fluxos, prototipagem e teste da arquitetura de informação | V0; validações UX de V1 e mapa da V3 |
| Lovable/Dyad | Protótipo visual descartável/validatório se ajudar; não aceitar como arquitetura final sem provar persistência em Markdown | V0, antes da escolha técnica |
| GitHub | Código, documentação, histórico, issues e releases | Todas as etapas; não colocar vault real com dados pessoais no repositório |

## Prompt padrão para abrir uma etapa com qualquer IA

> Leia `ATLAS_DE_INTERESSES_DOCUMENTACAO_OFICIAL.md` e `AI_CONTEXT.md`. Estamos na etapa **[V0/V1/V2/V3/V4/V5 + subetapa]**. Antes de implementar, resuma as regras inegociáveis relevantes, identifique decisões pendentes e proponha a menor entrega verificável. Liste critérios de aceite, arquivos que precisará alterar, riscos e testes. Não altere princípios nem antecipe recursos de versões posteriores sem explicar o impacto e solicitar aprovação. Não afirme testes sem executá-los.

## Registro de progresso

| Marco | Data de início | Data de conclusão | Estado | Evidência/link | Próxima ação |
|---|---|---|---|---|---|
| V0 | | | Não iniciado | | |
| V1 | | | Bloqueado por gate V0 | | |
| V2 | | | Bloqueado por gate V1 | | |
| V3 | | | Bloqueado por gate V2 | | |
| V4 | | | Bloqueado por gate V3 | | |
| V5 | | | Bloqueado por gate V4 | | |
