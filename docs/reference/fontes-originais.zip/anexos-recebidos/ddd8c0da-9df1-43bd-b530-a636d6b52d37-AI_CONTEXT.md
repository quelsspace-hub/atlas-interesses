# AI_CONTEXT.md — Atlas de Interesses

Use este arquivo como contexto compacto ao iniciar uma conversa com uma IA de produto, design ou desenvolvimento. A documentação oficial completa contém os detalhes do modelo de dados, telas, versões e critérios de aceite.

## O que é o Atlas

O Atlas de Interesses é um sistema pessoal que conecta exploração de interesses, gestão de projetos e base de conhecimento. Não é apenas um task manager ou app de notas: permite navegar por temas, capturar ideias, transformá-las em itens/projetos/tarefas e preservar conhecimento reutilizável.

## Princípios que não podem ser alterados sem aprovação

1. **Markdown é a fonte de verdade.** Os registros importantes devem continuar legíveis fora da interface. Índices e caches podem ser derivados e reconstruídos.
2. **Cada registro tem ID estável.** Renomear não cria uma nova entidade.
3. **Grupos são derivados por tags.** Um item aparece num grupo se compartilhar pelo menos uma tag com ele (OR). Não armazenar `group_ids` no item nem `item_ids` no grupo.
4. **Um item, múltiplas vistas.** O mesmo registro pode aparecer em diversos grupos/mapas sem cópias.
5. **Tags classificam; links conectam.** Links entre notas são links Markdown reais; backlinks são calculados.
6. **Arquivamento antes de exclusão silenciosa.** Não quebrar referências ao remover registros.
7. **Persistência real.** Não simular operações como se tivessem sido salvas. Validar após fechar e reabrir.
8. **Versões incrementais.** Implementar somente o escopo aprovado; não antecipar features das versões futuras.
9. **Uma IA implementadora por tarefa.** Outra IA pode revisar sem editar os mesmos arquivos simultaneamente.
10. **Honestidade nos testes.** Nunca alegar que algo foi testado sem executar o teste.

## Modelo da V1

- `Group`: `id`, `name`, `description`, `tag_ids`, ordem, estilo opcional e timestamps/arquivamento.
- `Tag`: `id`, `name`, `slug`, descrição/aliases/cor opcionais e timestamps/arquivamento.
- `Item`: `id`, tipo (`project`, `course`, `interest`, `idea`, `learning_path`, `goal`), título, resumo, `tag_ids`, status, prioridade/datas opcionais, URL/provedor opcionais, modo de progresso, objetivo/critério de sucesso e timestamps.
- `Task`: `id`, título, descrição, `project_id` opcional, status (`todo`, `in_progress`, `done`, `canceled`), prioridade/prazo opcionais, `is_next_action`, ordem, timestamps e `completed_at`.
- `Note`: `id`, tipo (`work`, `reading`, `permanent`), título, `context_item_id`, `tag_ids`, metadados opcionais da fonte, corpo Markdown e timestamps.
- `InboxCapture`: `id`, tipo de captura, status (`pending`, `processed`, `archived`), horário, conteúdo original e referência para a entidade convertida.

Progresso por tarefas: `done / (todo + in_progress + done) × 100`; tarefas canceladas são excluídas. Sem tarefas elegíveis, mostrar “Sem tarefas”/“Progresso não calculado”, não 0%.

## Navegação e requisito visual registrado

No **mapa conceitual de navegação**, a caixa “ATLAS DE INTERESSES” fica centralizada, com as áreas ao redor; não a desenhar como barra lateral fixa à esquerda. A V1 usa listas e páginas de detalhe; o canvas com zoom é V3.

Áreas da V1: Visão geral, Atlas/Grupos e itens, Caixa de entrada, Projetos, Tarefas, Notas, Organização e Configurações.

## Roadmap

- **V0 — Descoberta e prova técnica:** wireframes, decisão de arquitetura, prova de leitura/escrita Markdown, IDs, relações por tags, backup/restauração, repositório e plano de testes.
- **V1 — Núcleo local-first:** CRUD dos registros, grupos/tags/itens, projetos, tarefas/progresso, notas/link/backlinks, captura e Visão geral.
- **V2 — Pesquisa e fontes:** busca global, filtros, catálogo de fontes mais estruturado, índice reconstruível.
- **V3 — Mapa interativo:** canvas, zoom/pan, abrir detalhes, filtros e alternativa em lista.
- **V4 — Grafo geral:** ligações explícitas e derivadas, filtros, limites e abertura de detalhes.
- **V5 — Sync e Android:** sincronização, offline conforme definido, conflitos recuperáveis, backup e segurança.

Não implementar V2–V5 durante V1. V5 é o fim do roadmap inicial, não uma proibição de evoluções futuras.

## Workflow de IA recomendado

- **ChatGPT:** requisitos, arquitetura de produto, prompts, critérios de aceite e coerência entre versões.
- **Gemini Notebook (antigo NotebookLM):** pesquisa baseada nos documentos e fontes fornecidos; rastrear conclusões às fontes.
- **Cursor Agent:** implementador principal recomendado; pode explorar o repositório, editar arquivos, executar comandos e testes.
- **Codex ou Claude Code:** revisor independente ou alternativa ao Cursor; escolher no máximo uma IA implementadora por tarefa.
- **Figma/FigJam:** wireframes e protótipos de UX.
- **Lovable/Dyad:** no máximo protótipo visual até a V0 comprovar que sua arquitetura consegue cumprir o requisito de armazenamento em Markdown.
- **GitHub:** versionamento do código e documentos. Não colocar vault pessoal real no repositório.

## Regras para o trabalho atual

Antes de codificar, ler a documentação oficial completa. Planejar, declarar arquivos a alterar, riscos e testes. Implementar uma tarefa pequena por vez. Executar testes. Pedir revisão independente. Atualizar documentação e registrar o que foi realmente verificado. Não mudar o armazenamento principal para um banco remoto sem aprovação expressa.

## Prompt de início

“Leia este AI_CONTEXT.md e a documentação oficial completa do Atlas de Interesses. Resuma as decisões que você entende como inegociáveis, identifique o estágio atual e as decisões pendentes. Não implemente nada ainda. Proponha o próximo passo mais pequeno e verificável, com objetivo, critérios de aceite, arquivos envolvidos, riscos e testes. Não altere decisões de produto sem explicar as consequências e pedir aprovação.”
